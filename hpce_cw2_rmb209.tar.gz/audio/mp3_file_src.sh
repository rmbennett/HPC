#!/bin/bash
../local/bin/lame --mp3input --decode -t $1 -
